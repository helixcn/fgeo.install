library(testthat)
library(fgeo.abundance)

test_check("fgeo.abundance")
