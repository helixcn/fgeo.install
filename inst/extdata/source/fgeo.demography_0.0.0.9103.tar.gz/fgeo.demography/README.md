
<!-- README.md is generated from README.Rmd. Please edit that file -->

# <img src="https://i.imgur.com/vTLlhbp.png" align="right" height=88 /> Recruitment, mortality, growth

[![lifecycle](https://img.shields.io/badge/lifecycle-experimental-orange.svg)](https://www.tidyverse.org/lifecycle/#experimental)
[![Build
Status](https://travis-ci.org/forestgeo/fgeo.demography.svg?branch=master)](https://travis-ci.org/forestgeo/fgeo.demography)
[![Coverage
status](https://codecov.io/gh/forestgeo/fgeo.demography/branch/master/graph/badge.svg)](https://codecov.io/github/forestgeo/fgeo.demography?branch=master)
[![CRAN
status](https://www.r-pkg.org/badges/version/fgeo.demography)](https://cran.r-project.org/package=fgeo.demography)

## Installation

Install the pre-release version of **fgeo.demography**:

    # install.packages("devtools")
    devtools::install_github("forestgeo/fgeo.demography@pre-release")

Or install the development version of **fgeo.demography**:

    # install.packages("devtools")
    devtools::install_github("forestgeo/fgeo.demography")

Or [install all **fgeo** packages in one
step](https://forestgeo.github.io/fgeo/index.html#installation).

For details on how to install packages from GitHub, see [this
article](https://goo.gl/dQKEeg).

## Example

``` r
library(fgeo.demography)
library(fgeo.tool)
#> 
#> Attaching package: 'fgeo.tool'
#> The following object is masked from 'package:stats':
#> 
#>     filter

# `read_censuses()` help you use your .rdata files directly
path <- tool_example("rdata")
dir(path)
#> [1] "tree5.RData" "tree6.RData"

censuses <- read_censuses(path)
# Using `t()` for a nicer view
t(recruitment(censuses))
#> Detected dbh ranges:
#>   * `census1` = 40.4-193.
#>   * `census2` = 44.9-195.
#> Using dbh `mindbh = 0` and above.
#>      N2 R rate lower upper     time     date1 date2   
#> [1,] 3  0 0    0     0.2055579 4.486425 18996 20634.67
```

``` r
# Or create a census list with `as_censuses()`
tree5 <- fgeo.data::luquillo_tree5_random
tree6 <- fgeo.data::luquillo_tree6_random
cnss <- as_censuses(list(tree5, tree6))

# Using `t()` for a more confortable view
t(recruitment(cnss))
#> Detected dbh ranges:
#>   * `census1` = 10-955.
#>   * `census2` = 10.2-992.
#> Using dbh `mindbh = 0` and above.
#>      N2  R  rate       lower       upper      time     date1   date2  
#> [1,] 809 43 0.01205766 0.008953252 0.01622177 4.529631 18938.5 20594.2
```

``` r
# Group by species
result <- growth(cnss, by = "sp", quiet = TRUE)
# Showing only a few
lapply(result, head)
#> $rate
#>     ALCFLO     ALCLAT     ANDINE     ARDGLA     ARTALT     BRUPOR 
#> 4.20300765         NA 0.55542883 0.02191062 0.22217153         NA 
#> 
#> $N
#> ALCFLO ALCLAT ANDINE ARDGLA ARTALT BRUPOR 
#>      3      0      2      2      1      0 
#> 
#> $clim
#>       ALCFLO       ALCLAT       ANDINE       ARDGLA       ARTALT 
#> 9.882211e+00           NA 2.389817e+00 8.434552e-16           NA 
#>       BRUPOR 
#>           NA 
#> 
#> $dbhmean
#>   ALCFLO   ALCLAT   ANDINE   ARDGLA   ARTALT   BRUPOR 
#> 170.3333       NA 107.5000  19.1000  55.0000       NA 
#> 
#> $time
#>   ALCFLO   ALCLAT   ANDINE   ARDGLA   ARTALT   BRUPOR 
#> 4.505590       NA 4.501027 4.563997 4.501027       NA 
#> 
#> $date1
#>   ALCFLO   ALCLAT   ANDINE   ARDGLA   ARTALT   BRUPOR 
#> 18980.33       NA 18979.00 18855.00 18904.00       NA 
#> 
#> $date2
#> ALCFLO ALCLAT ANDINE ARDGLA ARTALT BRUPOR 
#>  20626     NA  20623  20522  20548     NA

# To dataframe with `to_df()`
to_df(mortality(cnss, by = "quadrat"))
#> Detected dbh ranges:
#>   * `census1` = 10-955.
#>   * `census2` = 10.2-992.
#> Using dbh `mindbh = 0` and above.
#> # A tibble: 3,231 x 3
#>    by    metric value
#>    <chr> <chr>  <dbl>
#>  1 1001  N          1
#>  2 1002  N          1
#>  3 1005  N          2
#>  4 1006  N          1
#>  5 1007  N          6
#>  6 1008  N          2
#>  7 101   N          1
#>  8 1010  N          3
#>  9 1011  N          2
#> 10 1013  N          1
#> # ... with 3,221 more rows
```

[Get started with
**fgeo**](https://forestgeo.github.io/fgeo/articles/fgeo.html)

## Information

  - [Getting help](SUPPORT.md).
  - [Contributing](CONTRIBUTING.md).
  - [Contributor Code of Conduct](CODE_OF_CONDUCT.md).

## Acknowledgements

Thanks to all partners of ForestGEO, for sharing their ideas and code.
