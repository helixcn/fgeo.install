library(testthat)
library(fgeo.demography)

test_check("fgeo.demography")
