#' Recruitment, mortality and growth, optionally aggregated by one variable.
#'
#' These generic functions calculate demography metrics across the entire
#' dataset or aggregated by one variable. They provide a new interface to lower
#' level functions adapted from the original CTFS-R package ([help
#' file](https://forestgeo.github.io/fgeo.ctfs/reference/demography_impl.html);
#' [source
#' code](https://github.com/forestgeo/fgeo.ctfs/blob/master/R/demography_impl.R)).
#' For an interface that more closely resembles those original functions, see
#' the functions referred to in the section _See Also_.
#'
#' Survivors are all individuals alive in both censuses, with `status == A` in
#' the first census, and larger than the minimum dbh in the first census. The
#' total population in the second census includes all those alive plus any other
#' survivors. Individuals whose status is NA in either census are deleted from
#' all calculations.
#'
#' @param censuses An object of class 'censuses_lst' or 'censuses_df' (created
#'   with [fgeo.tool::as_censuses()] or [fgeo.tool::read_censuses()]) containing
#'   two ForestGEO-like censuses. You may use a ForestGEO _stem_ table, but you
#'   should use a tree table because demography analyses make more sense at the
#'   scale of a tree than at the scale of stems.
#' @param by Optional string giving the name of a single variable to aggregate
#'   results by. Defaults to aggregating across the entire census datasets. To
#'   aggregate by multiple variables see section _Examples_.
#' @param quiet Use `TRUE` to suppress messages.
#' @param ... See below for the definition of each additional argument passed to
#'   [mortality_impl()] (`alivecode`), [recruitment_impl()] (`alivecode`,
#'   `mindbh`), and [growth_impl()] (`mindbh`, `rounddown`, `method`, `stdev`,
#'   `dbhunit`, `growthcol`, `err.limit`, `maxgrow`). See default values in the
#'   help file of each `*_impl()` function.
#'
#' @seealso [mortality_impl()], [recruitment_impl()], [growth_impl()].
#'
#' @section Deprecated arguments:
#' You should filter you data explicitly. These arguments remain but are
#' deprecated:
#' * `mindbh` conservatively defaults to `mindbh = 0`.
#' * `alivecode` defaults to c("A", "AB", "AS").
#'
#' @family functions for ForestGEO data.
#' @family functions for fgeo census.
#'
#' @return
#' Metrics of `recruitment()`: Similar to metrics of `mortality()`.
#'
#' Metrics of `mortality()`:
#' * `N`: the number of individuals alive in the census 1 per category
#'   selected.
#' * `D`: the number of individuals no longer alive in census 2.
#' * `rate`: the mean annualized mortality rate constant per category
#'   selected, calculated as (log(N)-log(S))/time.
#' * `upper`: upper confidence limit of mean rate.
#' * `lower`: lower confidence limit of mean rate.
#' * `time`: mean time interval in years.
#' * `date1`: mean date included individuals were measured in census 1, as
#'   julian object (R displays as date, but treats as integer).
#' * `date2`: mean date in census 2.
#' * `dbhmean`: mean dbh in census 1 of individuals included.
#'
#' Metrics of `growth()`:
#' * `rate`, the mean annualized growth rate per category selected, either dbh
#'   increment, or relative growth
#' * `N`, the number of individuals included in the mean (not counting any
#'   excluded)
#' * `clim` (or sd with `stdev = TRUE`), width of confidence interval; add this
#'   number to the mean rate to get upper confidence limit, substract to get
#'   lower
#' * `dbhmean`, mean dbh in census 1 of individuals included
#' * `time`, mean time interval in years
#' * `date1`, mean date included individuals were measured in census 1, as
#'   julian object (R displays as date, but treats as integer)
#' * `date2`, mean date in census 2.
#'
#' @examples
#' \dontrun{
#' if (!requireNamespace("fgeo.tool")) {
#'   stop("This example requires fgeo.tool. Please install it", call. = FALSE)
#' }
#'
#' library(fgeo.tool)
#'
#' censuses <- as_censuses(list(
#'   fgeo.x::tree5,
#'   fgeo.x::tree6
#' ))
#'
#' mortality(censuses)
#'
#' # growth() has many arguments you may want to explore.
#' growth_quadrat <- growth(censuses, by = "quadrat", quiet = TRUE)
#' lapply(growth_quadrat, head)
#'
#'
#' # Space-efficient view with t()
#' t(recruitment(censuses))
#'
#' recruitment_sp <- recruitment(censuses, by = "sp", quiet = TRUE)
#'
#' # In RStudio, try also: View(recruitment_sp)
#' lapply(recruitment_sp, head)
#'
#' # Converting the output of a dataframe
#' if (requireNamespace("fgeo.tool")) {
#'   library(fgeo.tool)
#'
#'   # Convert to dataframe
#'   sp_df <- to_df(recruitment_sp)
#'   head(sp_df)
#' }
#'
#' # Dataframes are easy to filter
#' head(subset(sp_df, metric == "N2"))
#' # For a wide layout see ?tidyr::spread()
#'
#' # Grouping by multiple variables ------------------------------------------
#' # Create a variable to group `by` that combines multiple other variables
#' cnss <- as_censuses(lapply(
#'   censuses, function(x) transform(x, sp_quad = paste(sp, quadrat))
#' ))
#' to_df(recruitment(cnss, by = "sp_quad"))
#'
#' # Mortality in a pipeline
#' example_data <- tool_example("rdata")
#' dir(example_data)
#'
#' example_data %>%
#'   read_censuses() %>%
#'   pick(dbh > 100) %>%
#'   mortality(by = "sp", quiet = TRUE) %>%
#'   to_df() %>%
#'   filter(by %in% c("PREMON", "DACEXC"), metric == "upper")
#' }
#' @name demography
NULL

# Generics ----------------------------------------------------------------

#' @rdname demography
#' @export
mortality <- function(censuses, ...) {
  UseMethod("mortality")
}

#' @rdname demography
#' @export
recruitment <- function(censuses, ...) {
  UseMethod("recruitment")
}

#' @rdname demography
#' @export
growth <- function(censuses, ...) {
  UseMethod("growth")
}

# Defaults ----------------------------------------------------------------

#' @export
#' @noRd
mortality.default <- function(censuses, ...) {
  message("See ?fgeo.tool::as_censuses() and ?fgeo.tool::read_censuses().")
  stop_bad_class(censuses)
}

#' @export
#' @noRd
recruitment.default <- mortality.default


#' @export
#' @noRd
growth.default <- mortality.default

# Implementation ----------------------------------------------------------

with_demography <- function(.f) {
  function(censuses, by = NULL, quiet = FALSE, ...) {
    check_with_demography(censuses, by)

    out <- .f(
      census1 = censuses[[1]],
      census2 = censuses[[2]],
      split1 = if (!is.null(by)) censuses[[1]][[by]],
      split2 = NULL,
      quiet = quiet,
      ...
    )

    if (is.null(by)) {
      return(new_demography_lst(out))
    }

    new_demography_lst_by(out)
  }
}

check_with_demography <- function(censuses, by) {
  # Checking by first because it's the shortest
  length1_name <- (length(by) == 1) && is.element(by, names(censuses[[1]]))
  if (!is.null(by) && !length1_name) {
    msg <- "`by` must be a length-1 string and the name of a census column."
    stop(msg, call. = FALSE)
  }

  if (!is.list(censuses) || is.data.frame(censuses)) {
    stop("`censuses` must be a non-dataframe list.", call. = FALSE)
  }

  if (length(censuses) != 2) {
    stop("`censuses` must be of length 2.", call. = FALSE)
  }

  n1 <- nrow(censuses[[1]])
  n2 <- nrow(censuses[[2]])
  if (!identical(n1, n2)) {
    stop(
      "Both censuses must have the same number of rows:\n",
      "* census1 has ", n1," rows.\n",
      "* census2 has ", n2," rows.\n",
      call. = FALSE
    )
  }
}

# Methods -----------------------------------------------------------------

#' @rdname demography
#' @export
mortality.censuses_lst <- with_demography(mortality_impl)

#' @rdname demography
#' @export
recruitment.censuses_lst <- with_demography(recruitment_impl)

#' @rdname demography
#' @export
growth.censuses_lst <- with_demography(growth_impl)

#' @rdname demography
#' @export
mortality.censuses_df <- function(censuses, ...) {
  mortality.censuses_lst(censuses$data, ...)
}

#' @rdname demography
#' @export
recruitment.censuses_df <- function(censuses, ...) {
  recruitment.censuses_lst(censuses$data, ...)
}

#' @rdname demography
#' @export
growth.censuses_df <- function(censuses, ...) {
  growth.censuses_lst(censuses$data, ...)
}

# Constructors ------------------------------------------------------------

new_demography_lst <- function(.x, ...) {
  stopifnot(is.list(.x))
  structure(.x, class = c("demography_lst", class(.x)))
}

new_demography_lst_by <- function(.x, ...) {
  stopifnot(is.list(.x))
  structure(.x, class = c("demography_lst_by", class(.x)))
}

# Print -------------------------------------------------------------------

#' @keywords internal
#' @export
#' @noRd
print.demography_lst <- function(x, ...) {
  print(unclass(x))
  invisible(x)
}

#' @keywords internal
#' @export
#' @noRd
print.demography_lst_by <- print.demography_lst
