stop_bad_class <- function(x) {
  stop(
    "Can't deal with data of class ", paste0(class(x), collapse = ", "),
    call. = FALSE
  )
}
