context("demography")

library(fgeo.tool)
library(dplyr)
library(bench)
library(fgeo.ctfs)



expect_ref <- function(object, file) {
  expect_known_output(object, file, print = TRUE, update = FALSE)
}

pluck_n <- function(.x, n) lapply(.x, function(x) x[1:n])

pick10sp <- function(.data) dplyr::filter(.data, sp %in% unique(.data$sp)[1:10])


tiny1 <- fgeo.x::tree5
tiny2 <- fgeo.x::tree6
censuses <- list(tiny1 = tiny1, tiny2 = tiny2)



test_that("census1 and census2 have the same species", {
  expect_equal(unique(tiny1$sp), unique(tiny2$sp))
})

test_that("with censuses_lst and censuses_df return the expected data structure", {
  skip_if_not_installed("fgeo.tool")
  library(fgeo.tool)
  censuses <- fgeo.tool::as_censuses(censuses)

  expect_is(mortality(censuses, quiet = TRUE), "demography_lst")
  expect_is(mortality(read_censuses(tool_example("rdata"))), "demography_lst")
})

test_that("demography functions aren't much slower than ctfs versions", {
  skip_if_not_installed("ctfs")
  skip_if_not_installed("fgeo.tool")
  library(fgeo.tool)

  # Times slower than ctfs that I allow fgeo functions to be
  limit <- 6

  cns <- new.env()
  list2env(censuses, cns)
  out <- mark(
    suppressMessages(ctfs::mortality(tiny1, tiny2)),
    suppressMessages(fgeo.demography:::mortality_impl(tiny1, tiny2, quiet = T)),
    suppressMessages(fgeo.demography::mortality(
      as_censuses(list(tiny1, tiny2)), quiet = T)
    ),
    iterations = 30,
    check = FALSE,
    env = cns
  )

  ctfs_reference <- out$median[[1]]
  times_mortality_impl <- as.double((out$median[[2]] / ctfs_reference))
  times_mortality <- as.double((out$median[[3]] / ctfs_reference))

  # # This will always fail. Enable only while refactoring to quickly see how far
  # # from the target I am
  # expect_equal(times_mortality_impl, 0)
  # expect_equal(times_mortality, 0)

  mortality_impl_too_slow <- times_mortality_impl > limit
  mortality_too_slow <- times_mortality > limit
  expect_false(any(mortality_impl_too_slow, mortality_too_slow))
})

describe("growth_impl() and growth() are sensitive to argument `method`", {
  it("growth_impl() outputs differently with different `method`s", {
    i <- growth_impl(tiny1, tiny2, method = "I")
    e <- growth_impl(tiny1, tiny2, method = "E")
    expect_false(identical(i, e))
  })

  it("growth() outputs differently with different `method`s", {
    skip_if_not_installed("fgeo.tool")
    library(fgeo.tool)
    censuses <- fgeo.tool::as_censuses(censuses)

    i <- growth(censuses, method = "I")
    e <- growth(censuses, method = "E")
    expect_false(identical(i, e))
    expect_named(e, c("rate", "N", "clim", "dbhmean", "time", "date1", "date2"))
  })
})

describe("recruitment(), mortality(), and growth()", {
  skip_on_travis()

  it("output objects of class demography_lst", {
    skip_if_not_installed("fgeo.tool")
    library(fgeo.tool)
    censuses <- as_censuses(censuses)
    expect_is(recruitment(censuses, quiet = TRUE), "demography_lst")
    expect_is(mortality(censuses, quiet = TRUE), "demography_lst")
    expect_is(growth(censuses, quiet = TRUE), "demography_lst")
  })

  it("are sensitive to argument `by`", {
    skip_if_not_installed("fgeo.tool")
    library(fgeo.tool)
    censuses <- as_censuses(censuses)
    expect_is(outr <- recruitment(censuses, quiet = TRUE), "list")
    expect_is(outm <- mortality(censuses, quiet = TRUE), "list")
    expect_is(outg <- growth(censuses, quiet = TRUE), "list")

    expect_is(out_byr <- recruitment(censuses, by = "sp", quiet = TRUE), "list")
    expect_is(out_bym <- mortality(censuses, by = "sp", quiet = TRUE), "list")
    expect_is(out_byg <- growth(censuses, by = "sp", quiet = TRUE), "list")

    expect_false(identical(outr, out_byr))
    expect_false(identical(outm, out_bym))
    expect_false(identical(outg, out_byg))
  })

  it("with bad input errs with informative message", {
    skip_if_not_installed("fgeo.tool")
    library(fgeo.tool)
    censuses <- as_censuses(censuses)

    expect_error(
      growth(as_censuses(c(censuses, censuses))),
      "must be of length 2"
    )

    # Legacy code grouped using `x$name` but now I use "name".
    msg <- "must be.*length-1.*string.*name"
    # Simple representation of census1$sp
    bad_by <- c("sp1", "sp2")
    expect_error(growth(censuses, by = bad_by), msg)
    expect_error(recruitment(censuses, by = bad_by), msg)
    expect_error(mortality(censuses, by = bad_by), msg)

    expect_error(growth(censuses, by = "not_a_name"), msg)

    censuses <- as_censuses(list(tiny1[1:10, ], tiny2[1:11, ]))
    expect_error(
      recruitment(censuses, quiet = TRUE),
      "Both censuses must have the same number of rows."
    )

    error_msg <- "Can't deal with data"
    info_msg <- "See.*as_censuses.*read_censuses"
    expect_message(expect_error(mortality(list(1)), error_msg), info_msg)
    expect_message(expect_error(recruitment(list(1)), error_msg), info_msg)
    expect_message(expect_error(growth(list(1)), error_msg), info_msg)
  })

  it("outputs the expected named elements", {
    skip_if_not_installed("fgeo.tool")
    library(fgeo.tool)
    censuses <- as_censuses(censuses)

    out <- recruitment(censuses, quiet = TRUE)
    nm_recr <- c("N2", "R", "rate", "lower", "upper", "time", "date1", "date2")
    expect_named(out, nm_recr)

    out <- growth(censuses, "sp", quiet = TRUE)
    nms_growth <- c("rate", "N", "clim", "dbhmean", "time", "date1", "date2")
    expect_named(out, nms_growth)
  })

  it("is sensitive to `quiet`", {
    skip_if_not_installed("fgeo.tool")
    library(fgeo.tool)
    censuses <- as_censuses(censuses)
    expect_message(growth(censuses), "Detected dbh ranges")
    expect_silent(growth(censuses, quiet = TRUE))
  })
})

describe("recruitment_impl(), mortality_impl(), and growth_impl()", {
  it("output identical to ctfs analogs", {
    skip_if_not_installed("ctfs")

    out1 <- fgeo.ctfs::recruitment_impl(
      tiny1, tiny2, split1 = tiny1$sp, quiet = TRUE
    )
    out2 <- ctfs::recruitment(tiny1, tiny2, split1 = tiny1$sp)
    expect_equal(out1, out2)

    out1 <- fgeo.ctfs::mortality_impl(
      tiny1, tiny2, split1 = tiny1$sp, quiet = TRUE
    )
    out2 <- ctfs::mortality(tiny1, tiny2, split1 = tiny1$sp)
    expect_equal(out1, out2)

    # Bug in ctfs::growth(); fixed in fgeo.ctfs::growth_impl().
    # Works
    expect_error(
      fgeo.ctfs::growth_impl(tiny1, tiny2, split1 = tiny1$sp, quiet = TRUE), NA
    )
    # Fails
    expect_error(ctfs::growth(tiny1, tiny2, split1 = tiny1$sp))
  })

  it("outputs an OK data structure", {
    r_luq_t <- recruitment_impl(tiny1, tiny2)
    expect_ref(r_luq_t, "ref-recruitment_impl_luq_tree")
    expect_type(r_luq_t, "list")
    expect_is(r_luq_t[[1]], "numeric")
    expect_length(r_luq_t, 8)
    expect_false(any(is.na(r_luq_t)))

    m_luq_t <- mortality_impl(tiny1, tiny2)
    expect_ref(m_luq_t, "ref-mortality_impl_luq_tree")
    expect_type(m_luq_t, "list")
    expect_is(m_luq_t[[1]], "numeric")
    expect_length(m_luq_t, 9)
    expect_false(any(is.na(m_luq_t)))

    g_luq_t <- growth_impl(tiny1, tiny2)
    expect_ref(g_luq_t, "ref-growth_impl_luq_tree")
    expect_type(m_luq_t, "list")
    expect_is(g_luq_t[[1]], "numeric")
    expect_length(g_luq_t, 7)
    expect_false(any(is.na(g_luq_t)))
  })

  it("errs if crucial variables are missing", {
    expect_error(recruitment_impl(rename(tiny1, bad = dbh), tiny2), "Ensure")
    expect_error(recruitment_impl(rename(tiny1, bad = hom), tiny2), "Ensure")
    expect_error(recruitment_impl(rename(tiny1, bad = status), tiny2), "Ensure")
    expect_error(recruitment_impl(rename(tiny1, bad = date), tiny2), "Ensure")

    expect_error(recruitment_impl(tiny1, rename(tiny2, bad = dbh)), "Ensure")
    expect_error(recruitment_impl(tiny1, rename(tiny2, bad = hom)), "Ensure")
    expect_error(recruitment_impl(tiny1, rename(tiny2, bad = status)), "Ensure")
    expect_error(recruitment_impl(tiny1, rename(tiny2, bad = date)), "Ensure")

    expect_error(mortality_impl(rename(tiny1, bad = dbh), tiny2), "Ensure")
    expect_error(mortality_impl(rename(tiny1, bad = hom), tiny2), "Ensure")
    expect_error(mortality_impl(rename(tiny1, bad = status), tiny2), "Ensure")
    expect_error(mortality_impl(rename(tiny1, bad = date), tiny2), "Ensure")

    expect_error(mortality_impl(tiny1, rename(tiny2, bad = dbh)), "Ensure")
    expect_error(mortality_impl(tiny1, rename(tiny2, bad = hom)), "Ensure")
    expect_error(mortality_impl(tiny1, rename(tiny2, bad = status)), "Ensure")
    expect_error(mortality_impl(tiny1, rename(tiny2, bad = date)), "Ensure")

    expect_error(growth_impl(rename(tiny1, bad = hom), tiny2), "Ensure")
    expect_error(growth_impl(rename(tiny1, bad = dbh), tiny2), "Ensure")
    expect_error(growth_impl(rename(tiny1, bad = status), tiny2), "Ensure")
    expect_error(growth_impl(rename(tiny1, bad = date), tiny2), "Ensure")
    expect_error(growth_impl(rename(tiny1, bad = stemID), tiny2), "Ensure")

    expect_error(growth_impl(tiny1, rename(tiny2, bad = dbh)), "Ensure")
    expect_error(growth_impl(tiny1, rename(tiny2, bad = hom)), "Ensure")
    expect_error(growth_impl(tiny1, rename(tiny2, bad = status)), "Ensure")
    expect_error(growth_impl(tiny1, rename(tiny2, bad = date)), "Ensure")
    # Not in recruitment_impl() or mortality_impl()
    expect_error(growth_impl(tiny1, rename(tiny2, bad = stemID)), "Ensure")
  })

  it("errs with informative message if censuses are missing", {
    expect_error(recruitment_impl(), "is missing, with no default")

    expect_error(mortality_impl(), "is missing, with no default")

    expect_error(growth_impl(), "is missing, with no default")
  })

  it("informs that `mindbh` is deprecated if quiet = FALSE", {
    expect_message(recruitment_impl(tiny1, tiny2, mindbh = 50), "is deprecated")
    expect_silent(recruitment_impl(tiny1, tiny2, mindbh = 50, quiet = TRUE))

    # Not applicabble for mortality_impl()
    expect_error(mortality_impl(tiny1, tiny2, mindbh = 50), "unused argument")

    expect_message(growth_impl(tiny1, tiny2, mindbh = 50), "is deprecated")
    expect_silent(growth_impl(tiny1, tiny2, mindbh = 50, quiet = TRUE))
  })

  it("informs that `alivecode` is deprecated if quiet = FALSE", {
    expect_message(recruitment_impl(tiny1, tiny2, alivecode = "A"), "is deprecated")
    expect_silent(recruitment_impl(tiny1, tiny2, alivecode = "A", quiet = TRUE))

    expect_message(mortality_impl(tiny1, tiny2, alivecode = "A"), "is deprecated")
    expect_silent(mortality_impl(tiny1, tiny2, alivecode = "A", quiet = TRUE))

    # Not applicable for growth_impl()
    expect_error(growth_impl(tiny1, tiny2, alivecode = "A"), "unused argument")
  })

  it("is sensitive to `alivecode`", {
    outA <- recruitment_impl(tiny1, tiny2, alivecode = "A")
    outD <- recruitment_impl(tiny1, tiny2, alivecode = "D")
    expect_warning(
      outBAD <- recruitment_impl(tiny1, tiny2, alivecode = "BAD"),
      "`alivecode` matches no value of `status`"
    )
    expect_false(identical(outA, outD))
    expect_true(all(is.na(outBAD)))

    outA <- mortality_impl(tiny1, tiny2, alivecode = "A")
    outD <- mortality_impl(tiny1, tiny2, alivecode = "D")
    expect_warning(
      outBAD <- mortality_impl(tiny1, tiny2, alivecode = "BAD"),
      "`alivecode` matches no value of `status`"
    )
    expect_false(identical(outA, outD))
    infinite <- is.infinite(unlist(outBAD))
    na <- is.na(unlist(outBAD))
    expect_true(any(infinite) || any(na))

    # Not applicable for growth_impl()
  })

  it("informs dbh range if quiet = FALSE", {
    expect_message(recruitment_impl(tiny1, tiny2), "Detected dbh ranges")
    expect_silent(recruitment_impl(tiny1, tiny2, quiet = TRUE))

    expect_message(mortality_impl(tiny1, tiny2), "Detected dbh ranges")
    expect_silent(mortality_impl(tiny1, tiny2, quiet = TRUE))

    expect_message(growth_impl(tiny1, tiny2), "Detected dbh ranges")
    expect_silent(growth_impl(tiny1, tiny2, quiet = TRUE))
  })

  it("warns if time difference is cero", {
    expect_warning(recruitment_impl(tiny1, tiny1), "Time difference is cero")

    expect_warning(mortality_impl(tiny1, tiny1), "Time difference is cero")

    expect_warning(growth_impl(tiny1, tiny1), "Time difference is cero")
  })

  it("errs if all dates are missing", {
    tiny1na <- tiny1
    tiny2na <- tiny2
    tiny1na$date <- NA
    tiny2na$date <- NA

    msg <- "Can't use `date`; all values are all missing."
    expect_error(growth_impl(tiny1na, tiny1na), msg)
    expect_error(mortality_impl(tiny1na, tiny1na), msg)
    expect_error(recruitment_impl(tiny1na, tiny1na), msg)
  })

  it("defaults to mindbh = 0", {
    out <- recruitment_impl(tiny1, tiny2)
    out0 <- recruitment_impl(tiny1, tiny2, mindbh = 0)
    expect_equal(out, out0)

    # Not applicable to mortality_impl()

    out <- growth_impl(tiny1, tiny2)
    out0 <- growth_impl(tiny1, tiny2, mindbh = 0)
    expect_equal(out, out0)
  })

  it("is sensitive to changing dbh", {
    out0 <- recruitment_impl(tiny1, tiny2, mindbh = 0)
    out100 <- recruitment_impl(tiny1, tiny2, mindbh = 100)
    expect_false(identical(out0, out100))

    # Not applicable to mortalit()

    out0 <- growth_impl(tiny1, tiny2, mindbh = 0)
    out100 <- growth_impl(tiny1, tiny2, mindbh = 100)
    expect_false(identical(out0, out100))
  })

  it("works with `split1`", {
    out1 <- recruitment_impl(tiny1, tiny2, split1 = tiny1$sp)
    expect_ref(out1, "ref-recruitment_impl_luq_tree_split1")
    # Output has the expected structure
    expect_type(out1, "list")
    expect_is(out1[[1]], "numeric")
    expect_length(out1, 8)
    expect_false(any(is.na(out1)))
    # Spliting by sp of census 1 or census 2 is the same
    out2 <- recruitment_impl(tiny1, tiny2, split1 = tiny2$sp)
    expect_true(identical(out1, out2))
    # and the result is different than not splitting at all
    out <- recruitment_impl(tiny1, tiny2)
    expect_false(identical(out, out2))

    out1 <- mortality_impl(tiny1, tiny2, split1 = tiny1$sp)
    expect_ref(out1, "ref-mortality_impl_luq_tree_split1")
    # Output has the expected structure
    expect_type(out1, "list")
    expect_is(out1[[1]], "numeric")
    expect_length(out1, 9)
    expect_false(any(is.na(out1)))
    # Spliting by sp of census 1 or census 2 is the same
    out2 <- mortality_impl(tiny1, tiny2, split1 = tiny2$sp)
    expect_true(identical(out1, out2))
    # and the result is different than not splitting at all
    out <- mortality_impl(tiny1, tiny2)
    expect_false(identical(out, out2))

    out1 <- growth_impl(tiny1, tiny2, split1 = tiny1$sp)
    expect_ref(out1, "ref-growth_impl_luq_tree_split1")
    # Output has the expected structure
    expect_type(out1, "list")
    expect_is(out1[[1]], "numeric")
    expect_length(out1, 7)
    expect_false(any(is.na(out1)))
    # Spliting by sp of census 1 or census 2 is the same
    out2 <- growth_impl(tiny1, tiny2, split1 = tiny2$sp)
    expect_true(identical(out1, out2))
    # and the result is different than not splitting at all
    out <- growth_impl(tiny1, tiny2)
    expect_false(identical(out, out2))
  })

  it("works with two splitting criteria", {
    out <-
      recruitment_impl(tiny1, tiny2, split1 = tiny1$sp, split2 = tiny1$quadrat)
    expect_ref(pluck_n(out, 100), "ref-recruitment_impl_luq_tree_split2")
    # Returns a list
    expect_type(out, "list")
    # but each element is no longer numeric but matrix
    expect_is(out[[1]], "matrix")

    out <-
      mortality_impl(tiny1, tiny2, split1 = tiny1$sp, split2 = tiny1$quadrat)

    expect_ref(pluck_n(out, 100), "ref-mortality_impl_luq_tree_split2")
    # Returns a list
    expect_type(out, "list")
    # but each element is no longer numeric but matrix
    expect_is(out[[1]], "matrix")

    out <-
      growth_impl(tiny1, tiny2, split1 = tiny1$sp, split2 = tiny1$quadrat)
    expect_ref(pluck_n(out, 100), "ref-growth_impl_luq_tree_split2")
    # Returns a list
    expect_type(out, "list")
    # but each element is no longer numeric but matrix
    expect_is(out[[1]], "matrix")
  })

  it("works with stem tables", {
    stem5 <- fgeo.x::stem5
    stem6 <- fgeo.x::stem6

    out <- recruitment_impl(stem5, stem6)
    expect_ref(out, "ref-recruitment_impl_luq_stem")
    expect_type(out, "list")
    expect_is(out[[1]], "numeric")
    expect_length(out, 8)
    expect_false(any(is.na(out)))

    out <- mortality_impl(stem5, stem6)
    expect_ref(out, "ref-mortality_impl_luq_stem")
    expect_type(out, "list")
    expect_is(out[[1]], "numeric")
    expect_length(out, 9)
    expect_false(any(is.na(out)))

    out <- growth_impl(stem5, stem6)
    expect_ref(out, "ref-growth_impl_luq_stem")
    expect_type(out, "list")
    expect_is(out[[1]], "numeric")
    expect_length(out, 7)
    expect_false(any(is.na(out)))
  })

  it("works with data from bci", {
    skip_if_not_installed("bciex")
    stem5 <- pick10sp(bciex::bci12s5mini)
    stem6 <- pick10sp(bciex::bci12s6mini)

    out <- recruitment_impl(stem5, stem6)
    expect_ref(out, "ref-recruitment_impl_bci_stem")
    expect_type(out, "list")
    expect_is(out[[1]], "numeric")
    expect_length(out, 8)
    expect_false(any(is.na(out)))

    out <- mortality_impl(stem5, stem6)
    expect_ref(out, "ref-mortality_impl_bci_stem")
    expect_type(out, "list")
    expect_is(out[[1]], "numeric")
    expect_length(out, 9)
    expect_false(any(is.na(out)))

    out <- growth_impl(stem5, stem6)
    expect_ref(out, "ref-growth_impl_bci_stem")
    expect_type(out, "list")
    expect_is(out[[1]], "numeric")
    expect_length(out, 7)
    expect_false(any(is.na(out)))



    tree5 <- pick10sp(bciex::bci12t5mini)
    tree6 <- pick10sp(bciex::bci12t6mini)

    out <- recruitment_impl(tree5, tree6)
    expect_ref(out, "ref-recruitment_impl_bci_tree")
    expect_type(out, "list")
    expect_is(out[[1]], "numeric")
    expect_length(out, 8)
    expect_false(any(is.na(out)))

    out <- mortality_impl(tree5, tree6)
    expect_ref(out, "ref-mortality_impl_bci_tree")
    expect_type(out, "list")
    expect_is(out[[1]], "numeric")
    expect_length(out, 9)
    expect_false(any(is.na(out)))

    out <- growth_impl(tree5, tree6)
    expect_ref(out, "ref-growth_impl_bci_tree")
    expect_type(out, "list")
    expect_is(out[[1]], "numeric")
    expect_length(out, 7)
    expect_false(any(is.na(out)))
  })
})

describe("<demography>() and <demography>_impl()", {
  skip_if_not_installed("fgeo.tool")
  library(fgeo.tool)
  censuses <- as_censuses(censuses)

  it("print as an unclassed list", {
  output <- capture_output(print(mortality(censuses, quiet = TRUE)))
  expect_false(grepl("demography_lst", output))
  output <- capture_output(print(mortality(censuses, "sp", quiet = TRUE)))
  expect_false(grepl("demography_lst_by", output))
  })
})
