context("from_var_to_var")

test_that("gxgy_to_qxqy() otputs the expected names", {
  out <- suppressMessages(gxgy_to_qxqy(c(1, 1), c(1, 1), gridsize = 20))
  expect_named(out, c("QX", "QY"))

})
