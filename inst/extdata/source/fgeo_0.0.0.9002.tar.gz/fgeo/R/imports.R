#' @importFrom rlang .data
NULL

globalVariables(c("."))
