library(testthat)
library(fgeo.habitat)

test_check("fgeo.habitat")
