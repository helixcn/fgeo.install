#' Datasets from __fgeo.data__.
#'
#' @family ForestGEO datasets
#'
#' @examples
#' str(luquillo_stem_random_tiny, give.attr = FALSE)
#' str(luquillo_vft_4quad, give.attr = FALSE)
#' @name luquillo
NULL

#' @rdname luquillo
"luquillo_stem_random_tiny"

#' @rdname luquillo
"luquillo_vft_4quad"
