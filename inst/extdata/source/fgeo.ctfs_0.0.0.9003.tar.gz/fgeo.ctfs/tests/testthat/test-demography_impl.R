context("demography_impl")

pick10sp <- function(x) {
  x[x$sp %in% unique(x$sp), ][1:10, ]
}
tiny1 <- pick10sp(fgeo.x::tree5)
tiny2 <- pick10sp(fgeo.x::tree6)

test_that("using `mindbh` prints a message after extracting desired `mindbh`", {
  expect_message(
    recruitment_impl(tiny1, tiny2, mindbh = 100),
    "Using dbh.*and above"
  )
})
