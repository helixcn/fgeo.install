#' Deprecated implementation of recruitment, mortality, and growth.
#'
#' @description
#' These functions are softy deprecated. To calculate recruitment, mortality and
#' growth you should use `fgeo.demography::recruitment()`,
#' `fgeo.demography::mortality()`, and `fgeo.demography::growth()`. The
#' functions documented here provide backward compatibility with the original
#' CTFS-R package.
#'
#' @section Warning:
#' Compared to the original functions from the CTFS-R package, these ones have a
#' similar interface, except that these functions use more conservative defaults
#' and allow suppressing messages. These functions also feature a number of
#' bug fixes, additional assertions, and improved messages.
#'
#' @param quiet Use `TRUE` to suppress messages.
#' @param census1,census2 Two census tables, each being a dataframe and in
#'   particular, a ForestGEO tree table. You may use a stem table, but you more
#'   commonly should use a tree table because demography analyses make more
#'   sense at the scale of a tree than at the scale of stems.
#' @param split1,split2 Optional vectors (column of any one the census
#'   dataframe) to aggregate results by. Defaults to aggregating across the
#'   entire census datasets.
#' @param alivecode (Deprecated) Character, codes of the variable `status` that
#'   indicate the tree is alive. The default 'A' is the standard CTFS
#'   designation for living trees or stems.
#' @param mindbh (Deprecated) The minimum diameter above which the counts are
#'   done. Trees smaller than `mindbh` are excluded. If `NULL`, all living trees
#'   are included.
#' @param rounddown If `TRUE``, all `dbh < 55` are rounded down to the nearest
#'   multiple of 5.
#' @param method Use "I" to calculate annual dbh increment as
#'   `(dbh2 - dbh1)/time`, or "E" to calculate the relative growth rate as
#'   `(log(dbh2) - log(dbh1)) / time`.
#' @param stdev Logical. Default (`FALSE`) returns confidence limits, otherwise
#'   returns the SD in growth rate per group.
#' @param dbhunit 'cm' or 'mm'.
#' @param growthcol defines how growth is measured, either 'dbh' or 'agb'
#'   (above ground biomass).
#' @param err.limit A number. Numbers such as 10000 are high and will return all
#'   measures.
#' @param maxgrow A number. Numbers such as 10000 are high and will return all
#'   measures.
#'
#' @author Rick Condit, Suzanne Lao.
#'
#' @family functions for ForestGEO data.
#' @family functions for fgeo census.
#' @family deprecated implementation
#'
#' @examples
#' \dontrun{
#' census1 <- fgeo.x::tree5
#' census2 <- fgeo.x::tree6
#' out <- recruitment_impl(census1, census2, split1 = census1$sp)
#' lapply(out, head)
#' }
#' @name demography_impl
NULL

# Recruitment -------------------------------------------------------------

#' @rdname demography_impl
#' @export
recruitment_impl <- function(census1,
                             census2,
                             mindbh = NULL,
                             alivecode = NULL,
                             split1 = NULL,
                             split2 = NULL,
                             quiet = FALSE) {
  prep <- wrap_prepare_recruitment_mortality(
    census1, census2, split1, split2, quiet, mindbh
  )
  census1 <- prep$census1
  census2 <- prep$census2
  split1 <- prep$split1
  split2 <- prep$split2
  inc <- prep$inc
  time <- prep$time

  check_alivecode(census1, census2, alivecode, quiet)
  alivecode <- alivecode %||% c("A", "AB", "AS")
  mindbh <- mindbh %||% 0

  survivor <- alive1 <- alive2 <- rep(FALSE, length(census1$status))
  alive1[census1$status == "A"] <- TRUE
  for (i in 1:length(alivecode)) {
    survivor[census1$status == "A" & census2$status == alivecode[i]] <- TRUE
    alive2[census2$status == alivecode[i]] <- TRUE
  }

  class1 <- sort(unique(split1))
  class2 <- sort(unique(split2))

  S.inc <- survivor & (census1$dbh >= mindbh)
  N2.inc <- (alive2 & (census2$dbh >= mindbh)) | S.inc

  splitS <- list(split1[S.inc], split2[S.inc])
  splitN <- list(split1[alive1], split2[alive1])
  splitN2 <- list(split1[N2.inc], split2[N2.inc])

  S <- tapply(census2$dbh[S.inc], splitS, length)
  N2 <- tapply(census2$dbh[N2.inc], splitN2, length)
  timeint <- tapply(time[N2.inc], splitN2, mean, na.rm = T)
  startdate <- tapply(census1$date[alive1], splitN, mean, na.rm = T)
  enddate <- tapply(census2$date[N2.inc], splitN2, mean, na.rm = T)

  S <- fill.dimension(S, class1, class2)
  N2 <- fill.dimension(N2, class1, class2)
  timeint <- fill.dimension(timeint, class1, class2, fill = NA)
  startdate <- fill.dimension(startdate, class1, class2, fill = NA)
  enddate <- fill.dimension(enddate, class1, class2, fill = NA)

  if (identical(sum(N2), 0)) {
    early <- list(
      N2 = rep(NA, length(class1)),
      R = rep(NA, length(class1)),
      rate = rep(NA, length(class1)),
      lower = rep(NA, length(class1)),
      upper = rep(NA, length(class1)),
      time = rep(NA, length(class1)),
      date1 = rep(NA, length(class1)),
      date2 = rep(NA, length(class1))
    )
    return(early)
  }

  lower.ci <- upper.ci <- N2
  lower.ci <- find.climits(as.matrix(N2), as.matrix(S), kind = "lower")
  upper.ci <- find.climits(as.matrix(N2), as.matrix(S), kind = "upper")

  rec.rate <- (log(N2) - log(S)) / timeint
  upper.rate <- (log(N2) - log(lower.ci)) / timeint
  lower.rate <- (log(N2) - log(upper.ci)) / timeint

  rec.rate[S == 0] <- upper.rate[S == 0] <- Inf
  upper.rate[lower.ci == 0] <- Inf
  rec.rate[N2 == 0] <- lower.rate[N2 == 0] <- upper.rate[N2 == 0] <- NA

  result <- list(
    N2 = drp(N2),
    R = drp(N2 - S),
    rate = drp(rec.rate),
    lower = drp(lower.rate),
    upper = drp(upper.rate),
    time = drp(timeint),
    date1 = drp(startdate),
    date2 = drp(enddate)
  )

  result
}

# Mortality ---------------------------------------------------------------

#' @rdname demography_impl
#' @export
mortality_impl <- function(census1,
                           census2,
                           alivecode = NULL,
                           split1 = NULL,
                           split2 = NULL,
                           quiet = FALSE) {
  prep <- wrap_prepare_recruitment_mortality(
    census1, census2, split1, split2, quiet,
    mindbh = NULL
  )
  census1 <- prep$census1
  census2 <- prep$census2
  split1 <- prep$split1
  split2 <- prep$split2
  inc <- prep$inc
  time <- prep$time

  check_alivecode(census1, census2, alivecode, quiet)
  alivecode <- alivecode %||% c("A", "AB", "AS")

  alive1 <- alive2 <- rep(FALSE, dim(census1)[1])
  alive1[census1$status == "A"] <- TRUE
  for (i in 1:length(alivecode)) alive2[census2$status == alivecode[i]] <- TRUE

  class1 <- sort(unique(split1))
  class2 <- sort(unique(split2))

  splitN <- list(split1[alive1], split2[alive1])
  splitS <- list(split1[alive1 & alive2], split2[alive1 & alive2])

  N <- tapply(census1$dbh[alive1], splitN, length)
  S <- tapply(census1$dbh[alive1 & alive2], splitS, length)
  meantime <- tapply(time[alive1], splitN, mean, na.rm = T)
  meandbh <- tapply(census1$dbh[alive1], splitN, mean, na.rm = T)
  startdate <- tapply(census1$date[alive1], splitN, mean, na.rm = T)
  enddate <- tapply(census2$date[alive1], splitN, mean, na.rm = T)

  N <- fill.dimension(N, class1, class2)
  S <- fill.dimension(S, class1, class2)
  meantime <- fill.dimension(meantime, class1, class2, fill = NA)
  meandbh <- fill.dimension(meandbh, class1, class2, fill = NA)
  startdate <- fill.dimension(startdate, class1, class2, fill = NA)
  enddate <- fill.dimension(enddate, class1, class2, fill = NA)

  if (identical(sum(N), 0)) {
    return(list(
      N = rep(NA, length(class1)), D = rep(NA, length(class1)),
      rate = rep(NA, length(class1)),
      lower = rep(NA, length(class1)), upper = rep(NA, length(class1)),
      time = rep(NA, length(class1)), dbhmean = rep(NA, length(class1)),
      date1 = rep(NA, length(class1)), date2 = rep(NA, length(class1))
    ))
  }

  m <- mortality.calculation(
    N = as.matrix(N), S = as.matrix(S), meantime = as.matrix(meantime)
  )

  # ord=order(drp(meandbh))
  result <- list(
    N = drp(m$N),
    D = drp(m$D),
    rate = drp(m$rate),
    lower = drp(m$lowerCI),
    upper = drp(m$upperCI),
    time = drp(m$time),
    date1 = drp(startdate),
    date2 = drp(enddate),
    dbhmean = drp(meandbh)
  )

  result
}

#' Internal.
#'
#' @family functions from http://ctfs.si.edu/Public/CTFSRPackage/
#' @keywords internal
#' @noRd
#' @author Rick Condit, Suzanne Lao.
mortality.calculation <- function(N, S, meantime) {
  lower.ci <- find.climits(N, (N - S), kind = "lower")
  upper.ci <- find.climits(N, (N - S), kind = "upper")

  mort.rate <- (log(N) - log(S)) / meantime
  upper.rate <- (log(N) - log(N - upper.ci)) / meantime
  lower.rate <- (log(N) - log(N - lower.ci)) / meantime


  mort.rate[S == 0] <- upper.rate[S == 0] <- Inf
  upper.rate[upper.ci == N] <- Inf
  lower.rate[lower.ci == N] <- 0
  mort.rate[N == 0] <- lower.rate[N == 0] <- upper.rate[N == 0] <- NA

  # TODO: This shuld be:
  # out <- list(...)
  # if (is.null(dim(N))) out <- data.frame(out)
  # out
  if (is.null(dim(N))) {
    return(
      data.frame(
        N = N,
        S = S,
        D = N - S,
        rate = mort.rate,
        lowerCI = lower.rate,
        upperCI = upper.rate,
        time = meantime
      )
    )
  } else {
    return(
      list(
        N = N,
        S = S,
        D = N - S,
        rate = mort.rate,
        lowerCI = lower.rate,
        upperCI = upper.rate,
        time = meantime
      )
    )
  }
}

# Growth ------------------------------------------------------------------

#' @rdname demography_impl
#' @export
growth_impl <- function(census1,
                        census2,
                        rounddown = FALSE,
                        method = "I",
                        stdev = FALSE,
                        dbhunit = "mm",
                        mindbh = NULL,
                        growthcol = "dbh",
                        err.limit = 1000,
                        maxgrow = 1000,
                        split1 = NULL,
                        split2 = NULL,
                        quiet = FALSE) {
  # More crucial names checked downstream
  lapply(list(census1, census2), check_crucial_names, "stemID")

  # TODO: check_method

  prep_d <- prepare_demography(census1, census2, split1, split2, quiet, mindbh)
  census1 <- prep_d$census1
  census2 <- prep_d$census2
  mindbh <- prep_d$mindbh
  split1 <- prep_d$split1
  split2 <- prep_d$split2

  if (is.null(mindbh)) mindbh <- 0

  size1 <- census1[[growthcol]]
  size2 <- census2[[growthcol]]

  if (is.null(split1)) {
    split1 <- rep("all", dim(census1)[1])
  }
  if (is.null(split2)) {
    split2 <- rep("all", dim(census2)[1])
  }
  if (is.null(census2$codes)) {
    census2$codes <- rep(".", length(size2))
  }

  time <- time_diff(census1, census2)

  if (rounddown) {
    sm <- ((size1 < 55 | size2 < 55) & !is.na(size1) & !is.na(size2))
    size1[sm] <- rndown5(size1[sm])
    size2[sm] <- rndown5(size2[sm])
  }

  if (method == "I") {
    growthrate <- (size2 - size1) / time
  } else if (method == "E") {
    growthrate <- (log(size2) - log(size1)) / time
  }

  good <- trim.growth(census1, census2, time,
    err.limit = err.limit,
    maxgrow = maxgrow, mindbh = mindbh
  )
  growthrate[!good] <- NA
  class1 <- sort(unique(split1))
  class2 <- sort(unique(split2))
  splitgood <- list(split1[good], split2[good])
  mean.grow <- tapply(growthrate[good], splitgood, mean, na.rm = TRUE)
  sd.grow <- tapply(growthrate[good], splitgood, sd, na.rm = TRUE)
  N <- tapply(growthrate[good], splitgood, length)
  meandbh <- tapply(census1$dbh[good], splitgood, mean, na.rm = TRUE)
  meansize <- tapply(size1[good], splitgood, mean, na.rm = TRUE)
  interval <- tapply(time[good], splitgood, mean, na.rm = TRUE)
  startdate <- tapply(census1$date[good], splitgood, mean, na.rm = TRUE)
  enddate <- tapply(census2$date[good], splitgood, mean, na.rm = TRUE)

  mean.grow <- fill.dimension(mean.grow, class1, class2, fill = NA)
  N <- fill.dimension(N, class1, class2, fill = 0)
  meandbh <- fill.dimension(meandbh, class1, class2, fill = NA)
  interval <- fill.dimension(interval, class1, class2, fill = NA)
  startdate <- fill.dimension(startdate, class1, class2, fill = NA)
  enddate <- fill.dimension(enddate, class1, class2, fill = NA)
  sd.grow <- fill.dimension(sd.grow, class1, class2, fill = NA)
  ci.grow <- sd.grow
  ci.grow[N == 0] <- NA
  ci.grow[N > 0] <- sd.grow[N > 0] * qt(0.975, N[N > 0]) / sqrt(N[N > 0])
  result <- list(
    rate = drp(mean.grow),
    N = drp(N),
    sd = drp(sd.grow),
    dbhmean = drp(meandbh),
    time = drp(interval),
    date1 = drp(startdate),
    date2 = drp(enddate)
  )

  if (!stdev) {
    result$sd <- NULL
    result <- append(result, list(clim = drp(ci.grow)), after = 2)
  }

  result
}

#' Internal.
#'
#' @family functions from http://ctfs.si.edu/Public/CTFSRPackage/
#' @keywords internal
#' @noRd
#' @author Rick Condit, Suzanne Lao.
graph.growthmodel <- function(spp,
                              fitlist,
                              whichbin = 1,
                              regclr = "green",
                              modelclr = "blue",
                              graphdiv = 10,
                              export = pdf,
                              outfile = "growth/linearbin.fit.pdf",
                              h = 8,
                              w = 10) {
  if (!is.null(export)) {
    on.exit(graphics.off())
    export(file = outfile, height = h, width = w)
  }
  for (onesp in spp) {
    if (is.null(export)) {
      grDevices::dev.new(height = 5, width = 9)
    }
    graph.growthmodel.spp(
      fit = fitlist[[onesp]][[whichbin]],
      graphdiv = 20, add = FALSE, modelclr = "blue", maintitle = onesp
    )
  }
}

#' Internal.
#'
#' @family functions from http://ctfs.si.edu/Public/CTFSRPackage/
#' @keywords internal
#' @noRd
#' @author Rick Condit, Suzanne Lao.
trim.growth <- function(cens1,
                        cens2,
                        time,
                        slope = 0.006214,
                        intercept = 0.9036,
                        err.limit = 4,
                        maxgrow = 75,
                        pomcut = 0.05,
                        mindbh = 10,
                        dbhunit = "mm",
                        exclude.stem.change = TRUE) {
  if (dbhunit == "cm") {
    intercept <- intercept / 10
  }
  stdev.dbh1 <- slope * cens1$dbh + intercept
  growth <- (cens2$dbh - cens1$dbh) / time
  bad.neggrow <- which(cens2$dbh <= (cens1$dbh - err.limit *
      stdev.dbh1))
  bad.posgrow <- which(growth > maxgrow)
  homdiff <- abs(as.numeric(cens2$hom) - as.numeric(cens1$hom)) / as.numeric(cens1$hom)
  accept <- rep(TRUE, length(cens1$dbh))
  accept[homdiff > pomcut] <- FALSE
  accept[bad.neggrow] <- FALSE
  accept[bad.posgrow] <- FALSE
  accept[is.na(growth)] <- FALSE
  if (exclude.stem.change) {
    accept[cens1$stemID != cens2$stemID] <- FALSE
  }
  accept[cens1$dbh < mindbh] <- FALSE
  accept[is.na(cens1$dbh) | is.na(cens2$dbh) | cens2$dbh <=
      0] <- FALSE
  return(accept)
}

#' Internal.
#'
#' @family functions from http://ctfs.si.edu/Public/CTFSRPackage/
#' @keywords internal
#' @noRd
#' @author Rick Condit, Suzanne Lao.
graph.growthmodel.spp <- function(fit,
                                  jiggle = 0.001,
                                  whichpred = "pred",
                                  xrange = NULL,
                                  yrange = NULL,
                                  xtitle = NULL,
                                  ytitle = NULL,
                                  includeaxs = TRUE,
                                  withSD = "red",
                                  regclr = "green",
                                  modelclr = "blue",
                                  modellwd = 1,
                                  graphdiv = 10,
                                  add = FALSE,
                                  addpts = TRUE,
                                  maintitle = NULL,
                                  conf = 0) {
  size <- fit$model$x
  obs <- fit$model$y
  if (whichpred == "meanpred") {
    pred <- fit$model$meanpred
  } else {
    pred <- fit$model$pred
  }
  if (is.null(yrange)) {
    yrange <- range(c(obs, pred))
  }
  if (is.null(xrange)) {
    xrange <- range(size)
  }
  if (is.null(xtitle)) {
    xtitle <- "log size"
  }
  if (is.null(ytitle)) {
    ytitle <- "growth"
  }
  xjiggle <- rnorm(length(size), mean = 0, sd = jiggle)
  yjiggle <- rnorm(length(size), mean = 0, sd = jiggle)
  if (addpts) {
    if (!add) {
      plot(size + xjiggle, obs + yjiggle,
        xlim = xrange,
        ylim = yrange, pch = 16, cex = 0.8, xlab = xtitle,
        ylab = ytitle, axes = includeaxs
      )
    } else {
      points(size + xjiggle, obs + yjiggle,
        pch = 16,
        cex = 0.8
      )
    }
  }
  else {
    if (add) {
      lines(size, pred, col = modelclr, lwd = modellwd)
    } else {
      plot(size, pred,
        type = "l", xlim = xrange, ylim = yrange,
        xlab = xtitle, ylab = ytitle, col = modelclr, lwd = modellwd,
        axes = includeaxs
      )
    }
  }
  b <- seq(min(size), max(size) + 1e-04, len = graphdiv - 1)
  sizecat <- cut(size, breaks = b, right = FALSE)
  if (conf > 0) {
    allparam <- fit$fullparam[fit$keep, ]
    noparam <- dim(allparam)[1]
    r <- sample(1:noparam, conf)
    for (i in 1:conf) {
      onepred <- linearmodel.bin(fit$model$x, param = allparam[r[i], ])
      lines(fit$model$x, onepred, col = "gray10", lwd = 0.5)
      if (i == 1) {
        meanpred <- onepred
      } else {
        meanpred <- meanpred + onepred
      }
    }
    lines(fit$model$x, meanpred / conf,
      lty = "dashed", lwd = 1.5,
      col = "purple"
    )
  }
  meansize <- tapply(size, sizecat, mean)
  meangrowth <- tapply(obs, sizecat, mean)
  if (!is.null(regclr)) {
    lines(meansize, meangrowth, col = regclr, lwd = modellwd)
  }
  if (addpts) {
    lines(size, pred, col = modelclr, lwd = modellwd)
  }
  if (!is.null(withSD)) {
    lines(size, pred + fit$model$predSD, col = withSD)
    lines(size, pred - fit$model$predSD, col = withSD)
  }
  ypos <- max(obs) - 0.3 * diff(range(obs))
  xpos <- min(size) + 0.1 * diff(range(size))
  if (!is.null(maintitle)) {
    text(xpos, ypos, maintitle, cex = 1.7, pos = 4)
  }
  return(data.frame(meansize, meangrowth))
}

#' Internal.
#'
#' @family functions from http://ctfs.si.edu/Public/CTFSRPackage/
#' @keywords internal
#' @noRd
#' @author Rick Condit, Suzanne Lao.
linearmodel.bin <- function(x, param, ...) {
  x <- as.matrix(x)
  extra <- list(...)
  if (is.null(extra$LINEARBINMEDIAN)) {
    medv <- 0
  } else {
    medv <- extra$LINEARBINMEDIAN
  }
  noparam <- length(param)
  bins <- (noparam) / 2
  if (is.null(medv)) {
    medv <- median(x)
  }
  if (bins == 1) {
    return(linear.model(x - medv, param))
  }
  b <- param[1:(bins - 1)] - medv
  v <- x - medv
  N <- length(b)
  m <- param[bins:(noparam - 1)]
  inter <- param[noparam]
  pred <- linearmodel.bin.set(v = v, binparam = b, param = c(
    m,
    inter
  ))
  return(pred)
}

#' Internal.
#'
#' @family functions from http://ctfs.si.edu/Public/CTFSRPackage/
#' @keywords internal
#' @noRd
#' @author Rick Condit, Suzanne Lao.
linearmodel.bin.set <- function(v, param, binparam) {
  m <- param[-length(param)]
  inter <- param[length(param)]
  failed <- rep(NA, length(v))
  if ((length(binparam) + 1) != length(m)) {
    return(failed)
  }
  sorted <- sort(binparam)
  if (length(which(sorted != binparam)) > 0) {
    return(failed)
  }
  K <- IfElse(
    diff(range(v)) > diff(range(binparam)), diff(range(v)),
    diff(range(binparam))
  )
  if (K == 0) {
    K <- 1
  }
  lower <- IfElse(min(v) < min(binparam), min(v) - K, min(binparam) -
      K)
  upper <- IfElse(max(v) > max(binparam), max(v) + K, max(binparam) +
      K)
  b <- c(lower, binparam, upper)
  bins <- length(m)
  N <- length(b)
  pts <- data.frame(x = b, y = rep(NA, N))
  if (upper < 0) {
    pts$y[N] <- inter + m[bins] * upper
    for (i in (N - 1):1) pts$y[i] <- pts$y[i + 1] - m[i] *
        (b[i + 1] - b[i])
  }
  else if (lower > 0) {
    pts$y[1] <- inter + m[1] * lower
    for (i in 2:N) pts$y[i] <- pts$y[i - 1] + m[i - 1] * (b[i] -
        b[i - 1])
  }
  else if (upper > 0) {
    z <- which(b > 0)[1]
    pts$y[z] <- inter + m[z - 1] * (b[z])
    for (i in (z - 1):1) pts$y[i] <- pts$y[i + 1] - m[i] *
      (b[i + 1] - b[i])
    if (z < N) {
      for (i in (z + 1):N) pts$y[i] <- pts$y[i - 1] + m[i -
          1] * (b[i] - b[i - 1])
    }
  }
  else if (upper == 0) {
    z <- which(b == 0)
    pts$y[z] <- inter + m[z - 1] * (b[z])
    for (i in (z - 1):1) pts$y[i] <- pts$y[i + 1] - m[i] *
      (b[i + 1] - b[i])
    if (z < N) {
      for (i in (z + 1):N) pts$y[i] <- pts$y[i - 1] + m[i -
          1] * (b[i] - b[i - 1])
    }
  }
  pred <- rep(NA, length(v))
  for (i in 1:bins) {
    start <- b[i]
    end <- b[i + 1]
    insection <- v >= start & v <= end
    thisline <- pts.to.interceptslope(pts[i, ], pts[i + 1, ])
    pred[insection] <- linear.model(v[insection], param = thisline)
  }
  return(pred)
}

#' Internal.
#'
#' @family functions from http://ctfs.si.edu/Public/CTFSRPackage/
#' @keywords internal
#' @noRd
#' @author Rick Condit, Suzanne Lao.
pts.to.interceptslope <- function(pt1, pt2) {
  if (is.null(dim(pt1))) {
    x1 <- pt1[1]
    y1 <- pt1[2]
  }
  else {
    x1 <- pt1[, 1]
    y1 <- pt1[, 2]
  }
  if (is.null(dim(pt2))) {
    x2 <- pt2[1]
    y2 <- pt2[2]
  }
  else {
    x2 <- pt2[, 1]
    y2 <- pt2[, 2]
  }
  len <- IfElse(length(x2) > length(x1), length(x2), length(x1))
  exact <- (x1 == x2)
  slope <- (y2 - y1) / (x2 - x1)
  inter <- y1 - slope * x1
  slope[exact] <- Inf
  inter[exact] <- x1[exact]
  result <- data.frame(b = inter, m = slope)
}

#' Internal.
#'
#' @family functions from http://ctfs.si.edu/Public/CTFSRPackage/
#' @keywords internal
#' @noRd
#' @author Rick Condit, Suzanne Lao.
linear.model <- function(x, param) {
  x <- as.matrix(x)
  nopredictor <- dim(x)[2]
  a <- param[1]
  b <- param[2:(nopredictor + 1)]
  return(a + x %*% b)
}

