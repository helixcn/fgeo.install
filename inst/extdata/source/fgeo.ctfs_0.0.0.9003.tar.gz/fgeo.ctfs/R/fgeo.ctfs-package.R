#' @keywords internal
"_PACKAGE"

