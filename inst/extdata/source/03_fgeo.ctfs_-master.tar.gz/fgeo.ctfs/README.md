
<!-- README.md is generated from README.Rmd. Please edit that file -->

# <img src="https://i.imgur.com/vTLlhbp.png" align="right" height=88 /> Code evolving from the CTFS R Package

[![lifecycle](https://img.shields.io/badge/lifecycle-experimental-orange.svg)](https://www.tidyverse.org/lifecycle/#experimental)
[![Travis build
status](https://travis-ci.org/forestgeo/fgeo.ctfs.svg?branch=master)](https://travis-ci.org/forestgeo/fgeo.ctfs)
[![Coverage
status](https://coveralls.io/repos/github/forestgeo/fgeo.ctfs/badge.svg)](https://coveralls.io/r/forestgeo/fgeo.ctfs?branch=master)
[![CRAN
status](https://www.r-pkg.org/badges/version/fgeo.ctfs)](https://cran.r-project.org/package=fgeo.ctfs)

The goal of **fgeo.ctfs** is to host code inherited from the [CFTS R
Package](http://ctfs.si.edu/Public/CTFSRPackage/), by Richard Condit,
and used in some of the **fgeo** packages.

## Installation

    # install.packages("devtools")
    devtools::install_github("forestgeo/fgeo.ctfs")

For details on how to install packages from GitHub, see [this
article](https://goo.gl/dQKEeg).

## Information

  - [Getting help](SUPPORT.md).
  - [Contributing](CONTRIBUTING.md).
  - [Contributor Code of Conduct](CODE_OF_CONDUCT.md).
