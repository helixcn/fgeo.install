#' @importFrom fgeo.ctfs mortality_impl recruitment_impl growth_impl
NULL

#' @name demography_impl
#'
#' @description
#' The source code of these functions is maintained in the __fgeo.ctfs__
#' package, and available
#' [here](https://github.com/forestgeo/fgeo.ctfs/blob/master/R/demography_impl.R).
#'
#' @inherit fgeo.ctfs::demography_impl
#'
#' @section Source code:
#' The source code of these functions is maintained in the
#' [__fgeo.ctfs__](https://forestgeo.github.io/fgeo.ctfs/) package, and
#' available
#' [here](https://github.com/forestgeo/fgeo.ctfs/blob/master/R/demography_impl.R).

#' @examples
#' census1 <- fgeo.x::tree5
#' census2 <- fgeo.x::tree6
#' out <- recruitment_impl(census1, census2, split1 = census1$sp)
#' lapply(out, head)
NULL

#' @rdname demography_impl
#' @export
mortality_impl <- fgeo.ctfs::mortality_impl

#' @rdname demography_impl
#' @export
recruitment_impl <- fgeo.ctfs::recruitment_impl

#' @rdname demography_impl
#' @export
growth_impl <- fgeo.ctfs::growth_impl



# Avoid CMD check notes
utils::globalVariables(c(".data"))
