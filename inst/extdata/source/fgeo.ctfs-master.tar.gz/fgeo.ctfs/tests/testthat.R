library(testthat)
library(fgeo.ctfs)

test_check("fgeo.ctfs")
