context("data")

library(fgeo.habitat)
library(dplyr)

test_that("expected datasets", {
  actual <- unname(sort(fgeo.base::find_datasets("fgeo.habitat")))
  expect_equal("luquillo_top3_sp", actual)
})
