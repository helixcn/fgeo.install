commas <- function(...) {
  paste0(..., collapse = ", ")
}
