#' A tiny dataset from Luquillo of the three most abundant species.
#'
#' @examples
#' str(luquillo_top3_sp)
"luquillo_top3_sp"

