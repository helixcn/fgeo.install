
<!-- README.md is generated from README.Rmd. Please edit that file -->

# <img src="https://i.imgur.com/vTLlhbp.png" align="right" height=88 /> Analize tree-habitat associations

[![lifecycle](https://img.shields.io/badge/lifecycle-experimental-orange.svg)](https://www.tidyverse.org/lifecycle/#experimental)
[![Travis build
status](https://travis-ci.org/forestgeo/fgeo.habitat.svg?branch=master)](https://travis-ci.org/forestgeo/fgeo.habitat)
[![Coverage
status](https://codecov.io/gh/forestgeo/fgeo.habitat/branch/master/graph/badge.svg)](https://codecov.io/github/forestgeo/fgeo.habitat?branch=master)
[![CRAN
status](http://www.r-pkg.org/badges/version/fgeo.habitat)](https://cran.r-project.org/package=fgeo.habitat)

## Installation

Install the development version of **fgeo.habitat**:

    # install.packages("devtools")
    devtools::install_github("forestgeo/fgeo.habitat")

Or [install all **fgeo** packages in one
step](https://forestgeo.github.io/fgeo/index.html#installation).

For details on how to install packages from GitHub, see [this
article](https://goo.gl/dQKEeg).

## Example

``` r
library(dplyr)
library(fgeo.tool)
library(fgeo.habitat)
```

### Species-habitat associations

``` r
tree <- fgeo.data::luquillo_tree5_random
elevation <- fgeo.data::luquillo_elevation

# Pick alive trees, of 10 mm or more
census <- filter(tree, status == "A", dbh >= 10)

# Pick sufficiently abundant species
pick <- filter(add_count(census, sp), n > 50)
species <- unique(pick$sp)

# Use your habitat data or create it from elevation data
habitat <- fgeo.tool::fgeo_habitat(elevation, gridsize = 20, n = 4)

# A list or matrices
tt_lst <- tt_test(census, species, habitat)
#> Using `plotdim = c(320, 500)`. To change this value see `?tt_test()`.
#> Using `gridsize = 20`. To change this value see `?tt_test()`.
tt_lst
#> [[1]]
#>        N.Hab.1 Gr.Hab.1 Ls.Hab.1 Eq.Hab.1 Rep.Agg.Neut.1 Obs.Quantile.1
#> CASARB      35     1508       90        2              0         0.9425
#>        N.Hab.2 Gr.Hab.2 Ls.Hab.2 Eq.Hab.2 Rep.Agg.Neut.2 Obs.Quantile.2
#> CASARB      24      433     1162        5              0       0.270625
#>        N.Hab.3 Gr.Hab.3 Ls.Hab.3 Eq.Hab.3 Rep.Agg.Neut.3 Obs.Quantile.3
#> CASARB      11      440     1157        3              0          0.275
#>        N.Hab.4 Gr.Hab.4 Ls.Hab.4 Eq.Hab.4 Rep.Agg.Neut.4 Obs.Quantile.4
#> CASARB       8      774      824        2              0        0.48375
#> 
#> [[2]]
#>        N.Hab.1 Gr.Hab.1 Ls.Hab.1 Eq.Hab.1 Rep.Agg.Neut.1 Obs.Quantile.1
#> PREMON      94     1511       87        2              0       0.944375
#>        N.Hab.2 Gr.Hab.2 Ls.Hab.2 Eq.Hab.2 Rep.Agg.Neut.2 Obs.Quantile.2
#> PREMON      97     1403      196        1              0       0.876875
#>        N.Hab.3 Gr.Hab.3 Ls.Hab.3 Eq.Hab.3 Rep.Agg.Neut.3 Obs.Quantile.3
#> PREMON      39      212     1386        2              0         0.1325
#>        N.Hab.4 Gr.Hab.4 Ls.Hab.4 Eq.Hab.4 Rep.Agg.Neut.4 Obs.Quantile.4
#> PREMON      15       64     1535        1              0           0.04
#> 
#> [[3]]
#>        N.Hab.1 Gr.Hab.1 Ls.Hab.1 Eq.Hab.1 Rep.Agg.Neut.1 Obs.Quantile.1
#> SLOBER      21      413     1183        4              0       0.258125
#>        N.Hab.2 Gr.Hab.2 Ls.Hab.2 Eq.Hab.2 Rep.Agg.Neut.2 Obs.Quantile.2
#> SLOBER      25      558     1040        2              0        0.34875
#>        N.Hab.3 Gr.Hab.3 Ls.Hab.3 Eq.Hab.3 Rep.Agg.Neut.3 Obs.Quantile.3
#> SLOBER      21     1289      309        2              0       0.805625
#>        N.Hab.4 Gr.Hab.4 Ls.Hab.4 Eq.Hab.4 Rep.Agg.Neut.4 Obs.Quantile.4
#> SLOBER       8      833      764        3              0       0.520625

# A simple summary to help you interpret the results
summary(tt_lst)
#>   Species Habitat_1 Habitat_2 Habitat_3 Habitat_4
#> 1  CASARB   neutral   neutral   neutral   neutral
#> 2  PREMON   neutral   neutral   neutral   neutral
#> 3  SLOBER   neutral   neutral   neutral   neutral

# A combined matrix
Reduce(rbind, tt_lst)
#>        N.Hab.1 Gr.Hab.1 Ls.Hab.1 Eq.Hab.1 Rep.Agg.Neut.1 Obs.Quantile.1
#> CASARB      35     1508       90        2              0       0.942500
#> PREMON      94     1511       87        2              0       0.944375
#> SLOBER      21      413     1183        4              0       0.258125
#>        N.Hab.2 Gr.Hab.2 Ls.Hab.2 Eq.Hab.2 Rep.Agg.Neut.2 Obs.Quantile.2
#> CASARB      24      433     1162        5              0       0.270625
#> PREMON      97     1403      196        1              0       0.876875
#> SLOBER      25      558     1040        2              0       0.348750
#>        N.Hab.3 Gr.Hab.3 Ls.Hab.3 Eq.Hab.3 Rep.Agg.Neut.3 Obs.Quantile.3
#> CASARB      11      440     1157        3              0       0.275000
#> PREMON      39      212     1386        2              0       0.132500
#> SLOBER      21     1289      309        2              0       0.805625
#>        N.Hab.4 Gr.Hab.4 Ls.Hab.4 Eq.Hab.4 Rep.Agg.Neut.4 Obs.Quantile.4
#> CASARB       8      774      824        2              0       0.483750
#> PREMON      15       64     1535        1              0       0.040000
#> SLOBER       8      833      764        3              0       0.520625

# A dataframe
dfm <- to_df(tt_lst)

# Using dplyr to summarize results by species and distribution
summarize(group_by(dfm, sp, distribution), n = sum(stem_count))
#> # A tibble: 3 x 3
#> # Groups:   sp [?]
#>   sp     distribution     n
#>   <chr>  <chr>        <dbl>
#> 1 CASARB neutral         78
#> 2 PREMON neutral        245
#> 3 SLOBER neutral         75
```

## Information

  - [Getting help](SUPPORT.md).
  - [Contributing](CONTRIBUTING.md).
  - [Contributor Code of Conduct](CODE_OF_CONDUCT.md).
