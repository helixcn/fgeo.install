library(testthat)
library(fgeo.base)

test_check("fgeo.base")
