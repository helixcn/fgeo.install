#' Example dataset with some columns of a ViewFullTable.
#' 
#' @examples
#' library(tibble)
#' 
#' example_byyr
"example_byyr"
