#' @keywords internal
"_PACKAGE"

# Imports -----------------------------------------------------------------

#' @importFrom utils ls.str
#' @importFrom rlang .data
NULL

globalVariables(c("."))
