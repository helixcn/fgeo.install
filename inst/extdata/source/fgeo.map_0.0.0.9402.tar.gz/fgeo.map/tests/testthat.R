library(testthat)
library(fgeo.map)

test_check("fgeo.map")
